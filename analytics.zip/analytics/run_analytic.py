#%%


import traceback
import ThresholdEstimator 
import logging

#%%

def run_analytic(data_json):
    """
    runs module
    Writes result in json file in 'Output' directory
    file_json_input : str, input json file name with path
    """

    try:       
        timestamp=[]
        ingestor=data_json[0]["ingestor"]
        measurement=data_json[0]["measurement"]
        startTime=data_json[0]["startTime"]
        endTime=data_json[0]["endTime"]
        upperThreshold=data_json[0]["upperThreshold"]
        lowerThreshold=data_json[0]["lowerThreshold"]
        total_value=[]  
#        endTime=((endTime- measurement[0][0])/100)+1#float(endTime)-float(startTime)
#        startTime=(startTime- measurement[0][0])/100
        for i in measurement:
              timestamp.append(i[0])
              total_value.append(i[1])
        diff=[]
        for index in range(0,len(timestamp)-1):
            diff.append(timestamp[index+1]-timestamp[index])
        diffavg=(sum(diff)/len(timestamp))
        startIndex=timestamp.index(startTime)
        endIndex=timestamp.index(endTime)
#        plt.figure(1)
#        plt.plot(timestamp,total_value)
#        plt.figure(2)
#        plt.plot(total_value)      
        #total_value=[0, 0, 0, 0, 0, 0, 0, 0, 0, 2460, 1080, 1500, 1200, 1080, 1020, 1380, 2940, 2400, 2700, 2460, 2460, 2580, 3300, 3480, 3240, 3660, 3660, 3900, 4080, 4200, 4200, 4200, 3660, 4020, 4260, 3540, 2940, 2040, 3180, 3120, 3180, 2880, 2940, 2820, 3540, 3720, 3300, 3300, 3300, 3540, 3480, 3600, 3480, 3420, 3660, 4500, 4620, 3960, 3780, 3720, 3840, 4080, 4080, 3840, 3840, 3840, 3840, 3840, 3840, 3900, 3540, 3900, 3900, 3780, 3900, 3960, 4020, 3840, 3780, 3660, 3840, 3900, 3900, 3720, 4020, 4020, 3840, 3780, 3660, 4200, 4080, 4380, 4140, 4620, 3120, 3960, 2340, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2400, 1680, 1680, 1800, 3120, 3540, 3720, 4080, 4020, 3960, 3960, 4080, 4080, 4200, 4080, 3300, 5760, 4140, 4140, 4140, 4140, 4140, 5220, 4080, 3900, 360, 0, 1140, 3120, 4980, 480, 660, 4020, 2880, 1980, 1560, 1860, 1140, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3420, 3600, 3660, 3840, 3480, 3660, 3540, 3540, 3600, 3420, 3420, 3300, 3360, 3360, 3480, 3600, 4440, 480, 3600, 3660, 3660, 3420, 3480, 3600, 3720, 3540, 3720, 3900, 3960, 3060, 3960, 3900, 4020, 3960, 3900, 1740, 3780, 3960, 3900, 3960, 4080, 4500, 2640, 3720, 3840, 3840, 4020, 5100, 2760, 3240, 3420, 3660, 3660, 3540, 3660, 3600, 3540, 3840, 3540, 3660, 6300, 3240, 6120, 3600, 4620, 960, 2640, 3660, 3660, 3660, 3660, 3600, 6420, 3840, 4080, 4140, 8760, 2820, 4440, 4680, 4740, 4980, 3600, 4320, 4440, 4620, 4800, 4860, 4740, 4620, 5340, 10560, 4560, 7140, 3060, 4800, 7440, 2520, 2280, 6780, 5580, 4380, 0, 0, 0, 0, 0]
        #print(zip([1513602023038+100*data for data in range(0,len(total_value))],total_value))
        print(startTime)
        print(endTime)
        values = ThresholdEstimator.Estimator(timestamp, total_value,startIndex,endIndex,upperThreshold,lowerThreshold,startTime,diffavg)
        result = {"data":[ {"ingestor":ingestor,"tag" :"Prediction","Result":[values]}]}
        return result
    except Exception, e:
        logging.error('Error in run_analytic', str(e))
       
        traceback.print_exc()
        
        