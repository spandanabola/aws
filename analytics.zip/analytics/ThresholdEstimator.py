# -*- coding: utf-8 -*-
"""
Created on Mon Feb 05 14:46:15 2018

@author: dnathani
"""



import numpy as np
import logging
from scipy.fftpack import fft,ifft
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures


def Estimator(timestamp, fanData,startTime,endTime,upperThreshold,lowerThreshold,startTimestamp,diffavg):
    
  try: 
    logging.info('--running ThresholdCalculator_analytic--')


    FilteredFFT=[]
    FFT_output=fft(fanData)
    Thershold=max(FFT_output)*0.05
    for data in FFT_output:
        if abs(data) < Thershold:
            FilteredFFT.append(0.0)
        else:
            FilteredFFT.append(data)
    FilteredData=ifft(FilteredFFT)
    RegressionInputData=FilteredData[startTime:endTime]
    
    
    
    ###############################################################################
    #Regression
    ###############################################################################
    Timescale=[[x] for x in range(0,len(RegressionInputData))]
    ###############################
    #Linear                      ##
    ###############################
    lr = LinearRegression()
    model = lr.fit(Timescale,RegressionInputData)
    #predictions = model.predict(Timescale)
    
    equSolver=np.poly1d(np.array(np.append(model.coef_.tolist()[::-1],(model.intercept_-float(lowerThreshold)))).tolist())
    print(equSolver)
    roots=np.roots(np.array(np.append(model.coef_.tolist()[::-1],(model.intercept_-float(lowerThreshold)))).tolist())
    print(roots)
    realRoots=[x for x in roots[np.isreal(roots)] if x >= 0]
    print(realRoots)
    RootData=[]
    try:
        for data2 in realRoots:
            if int(equSolver(data2)) == 0:
                RootData.append(data2)
        minRoot=min(RootData)
        LinearResultLow=(long(minRoot)*diffavg)+startTimestamp
    except Exception:
        LinearResultLow="Predicted Line does not intercept the Lower Threshold Line"
    
    equSolver=np.poly1d(np.array(np.append(model.coef_.tolist()[::-1],(model.intercept_-float(upperThreshold)))).tolist())
    print(equSolver)
    roots=np.roots(np.array(np.append(model.coef_.tolist()[::-1],(model.intercept_-float(upperThreshold)))).tolist())
    print(roots)
    realRoots=[x for x in roots[np.isreal(roots)] if x >= 0]
    print(realRoots)
    RootData=[]
    try:
        for data2 in realRoots:
            if int(equSolver(data2)) == 0:
                RootData.append(data2)
        minRoot=min(RootData)
        LinearResultHigh=(long(minRoot)*diffavg)+startTimestamp
    except Exception:
        LinearResultHigh="Predicted Line does not intercept the Upper Threshold Line"
    
    '''
    ###############################
    #Non Linear                  ##
    ###############################
    NonLinearAcc=[]
    for degreeValue in range(1,5):       
        #include_bias is to add all the polynomial with all the power equal to '0'
        poly = PolynomialFeatures(degree=degreeValue,include_bias=False)
        data_new = poly.fit_transform(Timescale)     
        lr2 = LinearRegression()
        model2 = lr2.fit(data_new,RegressionInputData)
        #predictions2 = model2.predict(data_new)
        NonLinearAcc.append(model2.score(data_new,RegressionInputData)*100)
    poly = PolynomialFeatures(degree=(NonLinearAcc.index(max(NonLinearAcc))+1),
                              include_bias=False)
    data_new = poly.fit_transform(Timescale)     
    lr2 = LinearRegression()
    model2 = lr2.fit(data_new,RegressionInputData)
    #predictions2 = model2.predict(data_new)
    
    equSolver=np.poly1d(np.array(np.append(model2.coef_.tolist()[::-1],(model2.intercept_-float(lowerThreshold)))).tolist())
    roots=np.roots(np.array(np.append(model2.coef_.tolist()[::-1],(model2.intercept_-float(lowerThreshold)))).tolist())
    realRoots=[x for x in roots[np.isreal(roots)] if x >= 0]
    
    RootData=[]
    try:
        for data2 in realRoots:
            if int(equSolver(data2)) == 0:
                RootData.append(data2)
        minRoot=min(RootData)
        NonLinearResultLow=float(minRoot)
    except Exception:
        NonLinearResultLow="Predicted Curve does not intercept the Lower Threshold Line"
    
    equSolver=np.poly1d(np.array(np.append(model2.coef_.tolist()[::-1],(model2.intercept_-float(upperThreshold)))).tolist())
    roots=np.roots(np.array(np.append(model2.coef_.tolist()[::-1],(model2.intercept_-float(upperThreshold)))).tolist())
    realRoots=[x for x in roots[np.isreal(roots)] if x >= 0]
    
    RootData=[]
    try:
        for data2 in realRoots:
            if int(equSolver(data2)) == 0:
                RootData.append(data2)
        minRoot=min(RootData)
        NonLinearResultHigh=float(minRoot)
    except Exception:
        NonLinearResultHigh="Predicted Curve does not intercept the Upper Threshold Line"

    '''
    return {"LinearLowerPrediction":LinearResultLow,"LinearUpperPrediction":LinearResultHigh}
  
    #return {"LinearLowerPrediction":LinearResultLow,"LinearUpperPrediction":LinearResultHigh,"NonLinearLowerPrediction":NonLinearResultLow,"NonLinearUpperPrediction":NonLinearResultHigh}
  except Exception, e:
            print(e)
            logging.error('Error in ThresholdCalculator_analytic', str(e))
            